// import connection from "../db"
// import  express  from "express";

// const router = express()




// router.get("/getusers",(req,res)=>{

//     connection.query("SELECT * FROM uploadfiles ",(err,result)=>{
//         if(err){
//             res.status(422).json("nodata available");
//         }else{
//             res.status(201).json(result);
//         }
//     })
// });