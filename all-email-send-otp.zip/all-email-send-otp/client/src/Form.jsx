

// import {useState} from 'react';
// import {senduser} from './api-calling/api'
// import ShowFiles from './ShowFiles';

// function Form() {
 
//   const [store, Setstore] = useState();
//   const [name, Setname] = useState();

// const sendValuedfiles = async()=>{
// // e.preventDefault()
// let formData = new FormData()
// formData.append('uploadfile',store) 
// formData.append('name',name) 
// console.log(store);
// console.log(formData);
//  await senduser(formData)

// }

// console.log(store);

//   return (
//    <>
//    <input type='text' name="name" onChange={(e)=>{Setname(e.target.value)}}/>
//         <input type="file" name="uploadfile" accept='csv' onChange={(e)=>{Setstore(e.target.files[0])}} />
//    <button onClick={sendValuedfiles}>submit</button>
  



//    <ShowFiles/>

// </>
//   );
// }

// export default Form;
